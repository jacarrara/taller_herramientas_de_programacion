package Ej01;

public class Ejercicio01 {

	public static void main(String[] args) {
		//Declaro e inicializo la variable num1
		int num1 = 0;
		
		//Le sumo 2
		num1 += 2;
		
		//Muestro por pantalla
		System.out.println("El valor de num1 es: " + num1);
		
		//Multiplico a num1 por si mismo
		num1 = num1*num1;
		
		//Muestro por pantalla
		System.out.println("Ahora el valor de num1 es: " + num1);
		
		

	}

}
