package Ej02;

public class Ejercicio02 {

	public static void main(String[] args) {
		
		//Declaro variables
		int num1, num2, suma, producto;
		
		//Inicializo num1
		num1 = 4;
		
		//Inicializo num2
		num2 = 5;
		
		//Hago la suma y lo guardo en la variable suma
		suma = num1 + num2;
		
		//Hago el producto y lo guardo en la variable producto
		producto = num1 * num2;
		
		//Muestro por pantalla
		System.out.println("La suma de num1 + num2 es: " + suma);
		
		//Muestro por pantalla
		System.out.println("El producto de num1 * num2 es: " + producto);

	}

}
